
<html>
<head>
 
    <style>
           body
    { 
        margin: 0;
	padding: 0;
    background: white url('f3.jfif') repeat-x left top;
background-size:cover;
	position:relative;
	font-family:Verdana, Arial, Helvetica, sans-serif;
font-size:10px;
line-height:12px;
text-align:justify;
padding-left:0px;

    }
     input[type=submit],input[type=text],input[type=date]{
          padding:12px 20px;
          box-sizing:borderbox;
          margin:8px 0;
          border:2px solid red;
        }
        #sidebar
        {
            width:200px;
            height:800px;
            background:	silver;
            float:left;
        }
        #header
        {
            overflow: hidden;
  background-color:	#e5f9ff;
  padding: 20px 10px;
        }
        #admin
        {
            background:white;
            border-radius:50px;
        }
        </style>
</head>
<body>
    <div id="sidebar">
    <form method="post" action="">
       <p> <input type="submit" name="view" value="view" ></p><br><br><br><br><br><br>
       <p> <input type="submit" name="dist" value="distribute" ></p><br><br><br><br><br><br>
       <p> <input type="submit" name="com" value="view comments" ></p></div>
</form>
    </div>
    <div id="header">
   <center><img src="t5.jfif" id="admin"><p style="font-color:white">this is admin page</p></center>
    </div>
 
</body>
</html>
<?php
include('connection.php');
//include('session.php');
mysql_select_db('project');
if(isset($_POST['view']))
{
    $select="select * from reportss";
    $result=mysql_query($select);
    echo "<table border='1' bgcolor='salmon'>";
    echo "<th>"."name"."</th>"."<th>"."type"."</th>"."<th>"."location"."</th>"."<th>"."phone"."</th>"."<th>"."date"."</th>";
    while($r=mysql_fetch_array($result,MYSQL_ASSOC))
    {
        echo "<tr>";
        echo "<td>".$r['name']."</td>";
        echo "<td>".$r['type']."</td>";
        echo "<td>".$r['location']."</td>";
        echo "<td>".$r['phone']."</td>";
        echo "<td>".$r['date']."</td>";
        echo "<td><a href=\"delete.php?name=$r[name]\" onclick=\"return confirm(' sure to delete?')\">delete</a></td>";
        echo "</tr>";
    }
    echo "</table>";
}
if(isset($_POST['com']))
{
    $select="select * from comments";
    $result=mysql_query($select);
    echo "<table border='1' bgcolor='salmon'>";
    while($r=mysql_fetch_array($result,MYSQL_ASSOC))
    {
        echo "<tr>";
        echo "<td>".$r['comment']."</td>";
        echo "</tr>";
    }
    echo "</table>";
}
if(isset($_POST['dist'])){
    echo "<table border='1'>";
echo "<form method='post'>";
echo "<tr><td>"."type:"."</td>"."<td><input type='text' name='type'></td></tr>"."<br>";
echo "<tr><td>"."quantity:"."<td><input type='text' name='quantity'></td></tr>"."<br>";
echo "<tr><td>"."date:"."</td>"."<td><input type='date' name='date'></td></tr>"."<br>";
echo  "<tr><td>"."<input type='submit' name='sub' value='report to police'>"."</td>"."<td><input type='submit' name='sub2' value='report to radio broadcast'></td></tr>";
echo "</form>";
}
if(isset($_POST['sub'])){
    $type=$_POST['type'];
    $quantit=$_POST['quantity'];
    $date=$_POST['date'];
    $insert="insert into police values('$type','$quantit','$date')";
    $result=mysql_query($insert);
    if(!$result){
        echo "error appeared".mysql_error();
    }
    }
    if(isset($_POST['sub2']))
    {
        $type=$_POST['type'];
        $quantit=$_POST['quantity'];
        $date=$_POST['date'];
        $insert="insert into radio values('$type','$quantit','$date')";
        $result=mysql_query($insert);
        if($result){
            echo "error appeared".mysql_error();
        }

    }
include('session.php');
    ?>
