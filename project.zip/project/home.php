<html>
    <head>
        <link href="style.css" rel="stylesheet" type="text/css">
        <style>
              .p{
          color:rgb(119, 17, 47);
          text-align:center;
          font-size: 20px;
          background-color: rgba(169, 133, 194, 0.486);
          background-size: cover;
          background-position:center ;
        }
          </style>
    </head>
    <body>
     
            <div >
               <ul class="ul">
                <li><a href="insert.php" target="_self">Report</a></li>
                <li><a href="about.php" target="_self">AboutUs</a></li>
                  <li><a href="contact.php" target="_self">Contact</a></li>
                  <li><a href="gallery.php" target="_self">Gallery</a></li>
                  <li><a href="home.php" target="_self">Home</a></li>  
               </ul>
</div><br></br><br>
<div class="photo">
		<img src="e2.jfif" alt="fire" height="200" width="200">
	</div><br><br><br><br>
               <div align="center">
                   <p style="font-size:50px;font-color:blue">accident and injury reporting</p>
</div>
<div class="p">
                
                  <p> Work-related incidents are tracked and investigated so that </p>
                  <p> preventative measures can be implemented.</p>
                   <p> The information contained in the reports is essential</p>
                   <p>  to maintain successful safety programs.</p>

              <p>It is important for work-related incidents to be reported so</p>
              <p> that they can be tracked and investigated.</p>
               <p> Once investigated, preventative measures can be implemented.</p>
               <p> The information contained in the reports is essential to </p>
               <p> maintain successful safety programs.<p>
               <p> The facts are necessary to develop procedures that can control both the<p>
                  <p>conditions and acts that contribute to incidents.</p> 
                  <p>Reporting is also required to help the University meet its compliance </p>
                  <p> responsibilities set by federal, state, and funding agencies.</p>

               <p> Report any work-related injury or illness to your supervisor as soon as possible. </p>

<p>When submitting a report, keep in mind:</p>

  <p> - Anyone with a with a pc can access the  Accident Reporting System (ARS).</p>
   <p>- Submit a report for near misses, hazardous conditions, and accidents or injuries involving employees,</p>
   <p> students, volunteers working on or off campus, or members of the public visiting campus.</p>
              </div>
            <footer> <div id="footer"><p style="text-align:center;font-size:20px;background:#dce8eb">	<i>University of Gondar </i></p>
                 <p style="text-align:center;background:#dce8eb">	<i>All Right Reserved&copy;2020|Gondar,Ethiopia|tel:0947462836 </i></p> </div></footer>
            </body>
    </html>