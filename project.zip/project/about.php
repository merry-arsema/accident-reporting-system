<html>
    <head>
        <link href="style.css" rel="stylesheet" type="text/css">
        <style>
        #sidebar
    {
        width:400px;
        height:800px;
        background:#dce8eb;
        float:right;
    }
    .photo img{
      height: 209px;
      border-radius: 70%;
      float: left;
      margin-top: 10px;
      margin-left: 100px;
      margin-right: 100px;
    }
    </style>
</head>
<body>
     
            <div >
               <ul class="ul">
                <li><a href="insert.php" target="_self">Report</a></li>
                <li><a href="about.php" target="_self">AboutUs</a></li>
                  <li><a href="contact.php" target="_self">Contact</a></li>
                  <li><a href="gallery.php" target="_self">Gallery</a></li>
                  <li><a href="home.php" target="_self">Home</a></li>  
               </ul>
            </div>
            <div class="photo">
		<img src="f5.jfif" alt="fire" height="200" width="200">
	</div>
            <div id="sidebar">
                <p>this website is created in order to</p>
                <p>make any user to give information</p>
                <p>on day-to-day activities of  lives.</p>
                <p>in order to a user report any type of</p>
                <p>accident anywhere to him/her,</p>
                <p>the website doesn't ask any requirements</p>
                <p>as other many websites.we create</p>
                <p>this website by the need of collecting</p>
                <p>accidents and ease the work of police</p>
                <p>and other bodies in-nees of accident reports.</p>
            </div>
            <footer> <div id="footer"><p style="text-align:center;font-size:20px;background:#dce8eb">	<i>University of Gondar </i></p>
                 <p style="text-align:center;background:#dce8eb">	<i>All Right Reserved&copy;2020|Gondar,Ethiopia|tel:0947462836 </i></p> </div></footer>
</body>
</html>