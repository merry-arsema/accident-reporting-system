<html>
    <head>
        <link href="style.css" rel="stylesheet" type="text/css">
       
    </head>
    <body>
     
            <div >
               <ul class="ul">
                <li><a href="insert.php" target="_self">Report</a></li>
                <li><a href="about.php" target="_self">AboutUs</a></li>
                  <li><a href="contact.php" target="_self">Contact</a></li>
                  <li><a href="gallery.php" target="_self">Gallery</a></li>
                  <li><a href="home.php" target="_self">Home</a></li>  
               </ul>
</div>
<section class="gallary" id="gallary">
	<h2> accident related images</h2>
	<div class="row">
		<div class="item">
			<a href="c1.jfif"><img src="c1.jfif" alt="merry" ></a>
		</div>
		<div  class="item">
			<a href="f2.jfif" ><img src="f2.jfif"  alt="merry"></a>
		</div>
		<div class="item">
			<a href="e1.jfif" ><img src="e1.jfif" alt="merry" ></a>
		</div>
		<div class="item">
			<a href="e2.jfif"><img src="e2.jfif" alt="merry" ></a>
		</div>
		<div class="item">
			<a href="e3.jfif" ><img src="e3.jfif" alt="merry"></a>
		</div>
		<div class="item">
			<a href="e4.jfif" ><img src="e4.jfif" alt="merry"></a>
		</div>
		<div class="item">
			<a href="e5.jfif" ><img src="e5.jfif" alt="merry" ></a>
		</div>
		<div class="item">
			<a href="f1.jfif" ><img src="f1.jfif" alt="merry" ></a>
		</div>
		<div class="item">
			<a href="f2.jfif" ><img src="f2.jfif" alt="merry"></a>
		</div>
		<div class="item">
			<a href="f3.jfif" ><img src="f3.jfif" alt="merry"></a>
		</div>
		<div class="item">
			<a href="f4.jfif" ><img src="f4.jfif" alt="merry" ></a>
		</div>
		<div class="item">
			<a href="f5.jfif" ><img src="f5.jfif" alt="merry"></a>
		</div>
		<div class="item">
			<a href="h1.jfif"><img src="h1.jfif" alt="merry"></a>
		</div>
		<div class="item">
			<a href="h2.jfif" ><img src="h2.jfif" alt="merry" ></a>
		</div>
		<div class="item">
			<a href="h3.jfif" ><img src="h3.jfif" alt="merry" ></a>
		</div>
		<div class="item">
			<a href="h4.jfif" ><img src="h4.jfif" alt="merry"></a>
		</div>
		<div class="item">
			<a href="t1.png" ><img src="t1.png" alt="merry"></a>
		</div>
		<div class="item">
			<a href="t2.jfif" ><img src="t2.jfif" alt="merry" ></a>
        </div>
        <div class="item">
			<a href="t3.png" ><img src="t3.png" alt="merry" ></a>
		</div>
		
	</div>
</section><br/><br/>
<footer> 
    <div id="footer"><p style="text-align:center;font-size:20px;background:#dce8eb">	<i>University of Gondar </i></p>
                 <p style="text-align:center;background:#dce8eb">	<i>All Right Reserved&copy;2020|Gondar,Ethiopia|tel:0947462836 </i></p> 
                </div></footer>
</body>
</html>