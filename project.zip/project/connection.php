<?php
$dbhost="localhost";
$dbusername="root";
$dbpassword='';
$conn=mysql_connect($dbhost,$dbusername,$dbpassword);

if(!$conn){
die("connection error: ".mysql_connect_error());
}
?>