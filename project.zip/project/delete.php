<?php
require('connection.php');
mysql_select_db('project');
$name=$_GET['name'];
$r=mysql_query("delete from reportss where name='$name'");
include('ad.php');
?>