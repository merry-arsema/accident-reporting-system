<?php
if(isset($_POST['login']))
{
    session_start();
    include('connection.php');
    mysql_select_db('project');
    if(empty($_POST['uname'])||empty($_POST['pwd']))
    {
      echo "<script>alert('empty user name or password')</script>";
      echo "<script>window.location='login.php'</script>";
    }
else
{
    $username=$_POST['uname'];
	$password=$_POST['pwd'];
	$ll="select * from admin where name='$username' AND password='$password'";
	$rt=mysql_query($ll);
     $jj=mysql_num_rows($rt);
     if($jj>0)
     {
         $_SESSION['user']=$username;
         echo "<script type='text/javascript'>
         window.location='ad.php'</script>";
     }
     else{
        echo "<script>alert('invalid username or password')</script>";
        echo "<script>window.location='login.php'</script>";
     }
}
}
?>  