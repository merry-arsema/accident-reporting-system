<?php
include('welcome.php');
?>
<html>
    <head>
      
        <style type="text/css">
        table
        {
       margin-top:150px;
       border:1px solid;
       background-color:#eee;
        }
        body
    { 
      background-image: url(f1.jfif);
      background-size: cover;
      background-position:center ;
      height:100vh;

    }
        td{
            border:0px;
            padding:10px;
        }
        th{
            border-bottom:1px solid;
            background-color:#ddd;
        }
        </style>
        </head>
        <body>
<form action="welcome.php" method="post">
    <table align="center">
        <tr>
            <th colspan="2"><h2 align="center">login</h2></th></tr>
            <tr>
                <td>username:</td>
                <td><input type="text" name="uname" placeholder="username"></td>
    </tr>
    <tr>
        <td>password:</td>
        <td><input type="password" name="pwd" placeholder="***********"></td>
    </tr>
    <tr>
        <td align="right" colspan="2"><input type="submit" name="login" value="login"></td>
    </tr>
    </table>
    </from>
    </body>
    </html>
