<html>
    <head>
        <link href="style.css" rel="stylesheet" type="text/css">
        <style>
              #sidebar
    {
        width:400px;
        height:800px;
        background:#dce8eb;
        float:left;
    }
    #sidebar img{
      margin-right:60px;
      height: 40px;
      border-radius: 90%;
    }
   #sidebar img a{
      line-height:50px;
      font-size: 26pt;
    }
    #footer{
      min-height: 60px;
      position:fixed;
      background-color:#dce8eb;
      bottom:0;
       width: 100%;
   }
           </style>
    </head>
    <body>
     
            <div >
               <ul class="ul">
                <li><a href="insert.php" target="_self">Report</a></li>
                <li><a href="about.php" target="_self">AboutUs</a></li>
                  <li><a href="contact.php" target="_self">Contact</a></li>
                  <li><a href="gallery.php" target="_self">Gallery</a></li>
                  <li><a href="home.php" target="_self">Home</a></li>  
               </ul>
            </div>
            <div id="sidebar">
               <p>telephone:0947462836</p>
               <p>0112781450</p>
               <p>0910295106</p>
               <p>email address:meronkabtu@gmail.com</p>
               <p>tigisthabtamu@gmail.com</p>
               <p>linaayalew@gmail.com</p>               
               <p><img src="facebook.png"><a href="www.facebook.com/Me Ran Merita"><h2>www.facebook.com/Me Ran Merita</h2></a></p>
             <p><img src="what.png"><a href="www.whatsapp.com/amana tegegne merry merry"><h2>www.whatsapp.com/Merry Merry</h2></a></p>
               <p><img src="instagram.jpeg"><a href="www.instagram.com/merry33272"><h2>www.instagram.com/merry33272</h2></a></p>
              </div>
           <form method="post">
              <p>you can give a comment in the following text area,don't hesitate to give any comments regardless of our website: </p>
              <textarea name="comm" rows=5 cols=5></textarea>
              <p><input type="submit" name="comment" value="send"></p>
</form>
<footer> <div id="footer"><p style="text-align:center;font-size:20px;background:#dce8eb">	<i>University of Gondar </i></p>
                 <p style="text-align:center;background:#dce8eb">	<i>All Right Reserved&copy;2020|Gondar,Ethiopia|tel:0947462836 </i></p> </div></footer>
</body>
</html>
<?php
include('connection.php');
mysql_select_db('project');
if(isset($_POST['comment'])){
   $accept=$_POST['comm'];
   $st="insert into comments values('$accept')";
  $ss= mysql_query($st);
  if($ss)
  {
     echo "u send the comment";
  }
}
?>