<?php
require('connection.php');
include("project.html");
echo "<br>";
mysql_select_db('project');
if(isset($_POST['submit']))
{
$name=$_POST['nm'];
$type=$_POST['select'];
$loc=$_POST['loc'];
$pnum=$_POST['pn'];
$date=$_POST['date'];
$insert="insert into reportss(name,type,location,phone,date) values('$name','$type','$loc','$pnum','$date')";
$result=mysql_query($insert);
if($result)
{
    echo  "<script>alert(successfully added)</script>";
}

}

?>
