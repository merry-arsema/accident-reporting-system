<html>
<head>
</head>
<body>
<?php
session_start();
if($_SESSION['user']=="")
{
	echo "<script type='text/javascript'>
		  alert('please first login')</script>";
echo "<script type='text/javascript'>
		  window.location='login.php'</script>";	
}
else
{
?>
<form method="post" action="session.php">
<p><input type="submit" name="user" value="logout"></p>
</form>
</body>
</html>
<?php
}
if(isset($_POST['user']))
{
	session_destroy();
	echo "<script type='text/javascript'>
		  window.location='login.php'</script>";
}
?>